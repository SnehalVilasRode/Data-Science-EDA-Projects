# EDA
1 Import Dataset & Headers
2 Identify Missing Data
3 Replace Missing Data
4 Evaluate Missing Data
5 Dealing with Missing Data
6 Correct Data Formats
7 Data standardization
8 Data Normalization
9 Binning
10 Indicator variable
